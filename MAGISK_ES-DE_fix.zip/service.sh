#!/system/bin/sh

MODDIR=${0%/*}
LOGFILE="/data/local/tmp/esde_themes_bind.log"
MARKER="/data/local/tmp/esde_themes_bind.started"

# Simple logging helper
log() {
    echo "[gammaos-esdefix][$(date +%F_%T)] $*" >> "$LOGFILE"
}

log "service.sh: starting (moddir=$MODDIR)"

# Wait until framework is up; the script uses cmd package, /storage/emulated/0, etc.
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    log "service.sh: waiting for sys.boot_completed"
    sleep 5
done

# Wait for external storage to be mounted; your script uses /storage/emulated/0/Android/data
while [ ! -d /storage/emulated/0/Android ]; do
    log "service.sh: waiting for /storage/emulated/0/Android"
    sleep 2
done

SCRIPT="/system/bin/esde_themes_bind.sh"

if [ -x "$SCRIPT" ]; then
    log "service.sh: starting daemon: $SCRIPT"
    touch "$MARKER"
    "$SCRIPT" >> "$LOGFILE" 2>&1 &
    log "service.sh: daemon launched (pid=$!)"
else
    log "service.sh: ERROR: script not found or not executable: $SCRIPT"
fi
